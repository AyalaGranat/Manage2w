package entity;

public enum Level {
	EASY,MEDIUM,HARD
}
