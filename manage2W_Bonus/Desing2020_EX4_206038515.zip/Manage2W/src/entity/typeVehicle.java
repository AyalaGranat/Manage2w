package entity;

public enum typeVehicle {
	BICYCLE,SCOOTER
}
